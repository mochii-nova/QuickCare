import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../../api";

function DoctorHome() {
  const navigate = useNavigate();
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(null);
  const [toast, setToast] = useState({ show: false, message: "", type: "" });
  const userData = JSON.parse(localStorage.getItem("userData") || "{}");

  const fetchAppointments = async () => {
    try {
      setLoading(true);
      const res = await API.get("/doctor/getdoctorappointments");
      if (res.data.success) {
        setAppointments(res.data.data);
      }
    } catch (err) {
      console.error("Error fetching appointments:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments();
  }, []);

  const showToast = (message, type = "success") => {
    setToast({ show: true, message, type });
    setTimeout(() => setToast({ show: false, message: "", type: "" }), 3000);
  };

  const handleStatus = async (appointmentId, status) => {
    setActionLoading(appointmentId);
    try {
      const res = await API.post("/doctor/handlestatus", { appointmentId, status });
      
      if (res.data.success) {
        // Refresh appointments immediately
        await fetchAppointments();
        // Show toast notification instead of alert
        showToast(`Appointment ${status} successfully!`, "success");
      } else {
        showToast(res.data.message || "Action failed", "error");
      }
    } catch (err) {
      console.error("Error updating status:", err);
      showToast("Something went wrong. Please try again.", "error");
    } finally {
      setActionLoading(null);
    }
  };

  const logout = () => {
    localStorage.clear();
    navigate("/login");
  };

  const statusColor = {
    pending: { bg: "#fff8e1", text: "#f39c12" },
    approved: { bg: "#e8f5e9", text: "#27ae60" },
    rejected: { bg: "#fce4ec", text: "#e74c3c" },
    completed: { bg: "#e3f2fd", text: "#2196f3" }
  };

  if (loading) return (
    <div className="text-center py-5">
      <div className="spinner-border text-info" role="status">
        <span className="visually-hidden">Loading...</span>
      </div>
      <p className="mt-2">Loading appointments...</p>
    </div>
  );

  return (
    <div className="dashboard-layout">
      {/* Toast Notification */}
      {toast.show && (
        <div style={{
          position: "fixed",
          top: "20px",
          right: "20px",
          zIndex: 9999,
          animation: "slideIn 0.3s ease"
        }}>
          <div className={`alert alert-${toast.type === "success" ? "success" : "danger"} shadow-lg`} style={{ borderRadius: 12 }}>
            {toast.type === "success" ? "✅ " : "❌ "}{toast.message}
          </div>
        </div>
      )}

      <aside className="sidebar">
        <span className="sidebar-logo">QuickCare</span>
        <p style={{ color: "#aaa", fontSize: "0.8rem", marginBottom: 20 }}>Doctor Panel</p>
        <ul className="sidebar-menu">
          <li>
            <button className="active">
              📅 My Appointments ({appointments.length})
            </button>
          </li>
          <li>
            <button onClick={logout}>🚪 Logout</button>
          </li>
        </ul>
      </aside>

      <main className="main-content">
        <header className="main-header">
          <h5 style={{ margin: 0, color: "#1a1a2e" }}>Dr. {userData.fullName}</h5>
          <span style={{ color: "#888", fontSize: "0.9rem" }}>Doctor Dashboard</span>
        </header>

        <div className="d-flex justify-content-between align-items-center mb-4">
          <h4>My Appointments</h4>
          <button 
            className="btn btn-sm btn-outline-info"
            onClick={fetchAppointments}
            disabled={loading}
          >
            🔄 Refresh
          </button>
        </div>

        {appointments.length === 0 ? (
          <div className="alert alert-info">No appointments yet.</div>
        ) : (
          <div className="table-responsive">
            <table className="table table-hover align-middle">
              <thead style={{ background: "#f8f9fa" }}>
                <tr>
                  <th>Patient</th>
                  <th>Date & Time</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {appointments.map((apt) => {
                  const colors = statusColor[apt.status] || statusColor.pending;
                  const isLoading = actionLoading === apt._id;
                  
                  return (
                    <tr key={apt._id} style={{ opacity: isLoading ? 0.6 : 1 }}>
                      <td>
                        <div style={{ fontWeight: 600 }}>{apt.userInfo?.fullName || "Patient"}</div>
                        <div style={{ fontSize: "0.85rem", color: "#888" }}>
                          📞 {apt.userInfo?.phone || ""}
                        </div>
                      </td>
                      <td style={{ whiteSpace: "nowrap" }}>{apt.date}</td>
                      <td>
                        <span style={{
                          background: colors.bg,
                          color: colors.text,
                          padding: "4px 12px",
                          borderRadius: 20,
                          fontWeight: 600,
                          fontSize: "0.8rem"
                        }}>
                          {apt.status}
                        </span>
                      </td>
                      <td>
                        {apt.status === "pending" && (
                          <div className="d-flex gap-2">
                            <button 
                              className="btn btn-sm btn-success"
                              onClick={() => handleStatus(apt._id, "approved")}
                              disabled={isLoading}
                            >
                              {isLoading ? "..." : "✓ Approve"}
                            </button>
                            <button 
                              className="btn btn-sm btn-danger"
                              onClick={() => handleStatus(apt._id, "rejected")}
                              disabled={isLoading}
                            >
                              {isLoading ? "..." : "✗ Reject"}
                            </button>
                          </div>
                        )}
                        {apt.status === "approved" && (
                          <button 
                            className="btn btn-sm btn-info"
                            onClick={() => handleStatus(apt._id, "completed")}
                            disabled={isLoading}
                          >
                            {isLoading ? "..." : "Complete"}
                          </button>
                        )}
                        {apt.status === "completed" && (
                          <span className="text-success">✓ Completed</span>
                        )}
                        {apt.status === "rejected" && (
                          <span className="text-danger">✗ Rejected</span>
                        )}
                       </td>
                     </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </main>

      <style>{`
        @keyframes slideIn {
          from {
            transform: translateX(100%);
            opacity: 0;
          }
          to {
            transform: translateX(0);
            opacity: 1;
          }
        }
      `}</style>
    </div>
  );
}

export default DoctorHome;
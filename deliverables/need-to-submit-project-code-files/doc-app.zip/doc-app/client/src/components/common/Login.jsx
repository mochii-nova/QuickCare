import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import API from "../../api";

function Login() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await API.post("/user/login", form);
      console.log("Login response:", res.data);
      
      if (res.data.success) {
        // Store token and user data
        localStorage.setItem("token", res.data.token);
        localStorage.setItem("userData", JSON.stringify(res.data.userData));
        
        const userType = res.data.userData.type;
        console.log("User type:", userType);
        
        if (userType === "admin") {
          navigate("/adminhome");
        } else if (res.data.userData.isdoctor) {
          navigate("/doctorhome");
        } else {
          navigate("/userhome");
        }
      } else {
        setError(res.data.message);
      }
    } catch (error) {
      console.error("Login error:", error);
      setError(error.response?.data?.message || "Login failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-wrapper">
      <div className="auth-card">
        <h2>Sign in to your account</h2>
        {error && <div className="alert alert-danger py-2">{error}</div>}
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Email</label>
            <input
              className="form-control"
              type="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              required
              placeholder="you@example.com"
            />
          </div>
          <div className="form-group">
            <label>Password</label>
            <input
              className="form-control"
              type="password"
              name="password"
              value={form.password}
              onChange={handleChange}
              required
              placeholder="••••••••"
            />
          </div>
          <button
            className="btn btn-info text-white w-100 mt-2"
            type="submit"
            disabled={loading}
          >
            {loading ? "Signing in…" : "Let's Enter"}
          </button>
        </form>
        <p className="mt-3 text-center" style={{ fontSize: "0.9rem" }}>
          Don't have an account?{" "}
          <Link to="/register" style={{ color: "#0288d1" }}>
            Register here
          </Link>
        </p>
      </div>
    </div>
  );
}

export default Login;
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import API from "../../api";

function Register() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    fullName: "",
    email: "",
    password: "",
    phone: "",
    type: "user",
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await API.post("/user/register", form);
      if (res.data.success) {
        navigate("/login");
      } else {
        setError(res.data.message);
      }
    } catch {
      setError("Registration failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-wrapper">
      <div className="auth-card">
        <h2>Sign up to your account</h2>
        {error && <div className="alert alert-danger py-2">{error}</div>}
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Full Name</label>
            <input
              className="form-control"
              name="fullName"
              value={form.fullName}
              onChange={handleChange}
              required
              placeholder="Your Name"
            />
          </div>
          <div className="form-group">
            <label>Email</label>
            <input
              className="form-control"
              type="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              required
              placeholder="you@example.com"
            />
          </div>
          <div className="form-group">
            <label>Password</label>
            <input
              className="form-control"
              type="password"
              name="password"
              value={form.password}
              onChange={handleChange}
              required
              placeholder="••••••••"
            />
          </div>
          <div className="form-group">
            <label>Phone</label>
            <input
              className="form-control"
              name="phone"
              value={form.phone}
              onChange={handleChange}
              required
              placeholder="09123456789"
            />
          </div>
          <div className="form-group">
            <label>Role</label>
            <div className="d-flex gap-3 mt-1">
              {["user", "admin"].map((role) => (
                <label key={role} style={{ cursor: "pointer", display: "flex", alignItems: "center", gap: 6 }}>
                  <input
                    type="radio"
                    name="type"
                    value={role}
                    checked={form.type === role}
                    onChange={handleChange}
                  />
                  {role.charAt(0).toUpperCase() + role.slice(1)}
                </label>
              ))}
            </div>
          </div>
          <button
            className="btn btn-info text-white w-100 mt-2"
            type="submit"
            disabled={loading}
          >
            {loading ? "Registering…" : "Register"}
          </button>
        </form>
        <p className="mt-3 text-center" style={{ fontSize: "0.9rem" }}>
          Have an account?{" "}
          <Link to="/login" style={{ color: "#0288d1" }}>
            Login here
          </Link>
        </p>
      </div>
    </div>
  );
}

export default Register;
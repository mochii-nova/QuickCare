import { useState, useEffect } from "react";
import API from "../../api";

function Notification() {
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState("unread");
  const [loading, setLoading] = useState(false);

  const fetchUserData = async () => {
    try {
      setLoading(true);
      const res = await API.post("/user/getuserdata", {});
      if (res.data.success) {
        const updatedUser = res.data.data;
        localStorage.setItem("userData", JSON.stringify(updatedUser));
        setUser(updatedUser);
        console.log("User data refreshed:", updatedUser);
        console.log("Notifications:", updatedUser.notification);
      }
    } catch (err) {
      console.error("Error fetching user data:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const stored = localStorage.getItem("userData");
    if (stored) {
      setUser(JSON.parse(stored));
    }
    // Fetch fresh data on component mount
    fetchUserData();
  }, []);

  const markAllRead = async () => {
    try {
      const res = await API.post("/user/getallnotification", {});
      if (res.data.success) {
        await fetchUserData(); // Refresh after marking read
      }
    } catch (err) {
      console.error(err);
    }
  };

  const deleteAll = async () => {
    try {
      const res = await API.post("/user/deleteallnotification", {});
      if (res.data.success) {
        await fetchUserData(); // Refresh after deleting
      }
    } catch (err) {
      console.error(err);
    }
  };

  if (!user) return <div className="text-center py-5">Loading...</div>;

  const unread = user.notification || [];
  const read = user.seennotification || [];

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h4 style={{ color: "#1a1a2e", margin: 0 }}>Notifications</h4>
        <button 
          className="btn btn-sm btn-outline-info"
          onClick={fetchUserData}
          disabled={loading}
        >
          🔄 Refresh
        </button>
      </div>
      
      <div className="d-flex gap-2 mb-4">
        <button
          className={`btn btn-sm ${activeTab === "unread" ? "btn-info text-white" : "btn-outline-secondary"}`}
          onClick={() => setActiveTab("unread")}
        >
          Unread ({unread.length})
        </button>
        <button
          className={`btn btn-sm ${activeTab === "read" ? "btn-info text-white" : "btn-outline-secondary"}`}
          onClick={() => setActiveTab("read")}
        >
          Read ({read.length})
        </button>
      </div>

      {activeTab === "unread" && (
        <>
          {unread.length > 0 ? (
            <>
              <button className="btn btn-sm btn-outline-info mb-3" onClick={markAllRead}>
                Mark all as read
              </button>
              {unread.map((n, i) => (
                <div key={i} className="doctor-card mb-2" style={{ borderLeft: "4px solid #0288d1" }}>
                  <p style={{ margin: 0, color: "#333" }}>{n.message}</p>
                  <small style={{ color: "#888" }}>
                    {n.type} • {n.createdAt ? new Date(n.createdAt).toLocaleString() : "Just now"}
                  </small>
                </div>
              ))}
            </>
          ) : (
            <div className="alert alert-info">
              No unread notifications. 
              {user.isdoctor && user.type !== "admin" && (
                <span> Your doctor application status will appear here when reviewed by an admin.</span>
              )}
            </div>
          )}
        </>
      )}

      {activeTab === "read" && (
        <>
          {read.length > 0 ? (
            <>
              <button className="btn btn-sm btn-outline-danger mb-3" onClick={deleteAll}>
                Delete all
              </button>
              {read.map((n, i) => (
                <div key={i} className="doctor-card mb-2" style={{ borderLeft: "4px solid #aaa", opacity: 0.7 }}>
                  <p style={{ margin: 0, color: "#555" }}>{n.message}</p>
                  <small style={{ color: "#aaa" }}>
                    Read • {n.createdAt ? new Date(n.createdAt).toLocaleString() : ""}
                  </small>
                </div>
              ))}
            </>
          ) : (
            <div className="alert alert-secondary">No read notifications</div>
          )}
        </>
      )}
    </div>
  );
}

export default Notification;
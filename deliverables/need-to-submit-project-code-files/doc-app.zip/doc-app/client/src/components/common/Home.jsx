import { Link } from "react-router-dom";

function Home() {
  return (
    <>
      <nav className="navbar navbar-expand-lg" style={{ background: "#1a1a2e", padding: "14px 32px" }}>
        <Link className="navbar-brand" to="/" style={{ color: "#4fc3f7", fontWeight: 700, fontSize: "1.3rem" }}>
          QuickCare
        </Link>
        <div className="ms-auto d-flex gap-2">
          <Link to="/login" className="btn btn-outline-light btn-sm">Login</Link>
          <Link to="/register" className="btn btn-info btn-sm text-white">Register</Link>
        </div>
      </nav>

      <div className="home-container">
        <div className="left-side">
          <p className="f-letter">Effortlessly Schedule<br />Your Doctor</p>
          <p className="s-letter">Appointments with just a few clicks,</p>
          <p className="t-letter">Putting your health in your hands.</p>
          <Link to="/login" className="btn btn-info text-white px-4 py-2" style={{ borderRadius: 8 }}>
            Book your Doctor
          </Link>
        </div>
        <div className="right-side">
          <div
            style={{
              width: 380,
              height: 320,
              background: "linear-gradient(135deg, #e0f2fe, #bae6fd)",
              borderRadius: 28,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              boxShadow: "0 20px 35px -10px rgba(0,0,0,0.15)",
              border: "1px solid rgba(79,195,247,0.3)",
              transition: "transform 0.25s ease",
              cursor: "default",
            }}
            onMouseEnter={(e) => e.currentTarget.style.transform = "scale(1.02)"}
            onMouseLeave={(e) => e.currentTarget.style.transform = "scale(1)"}
          >
            <div style={{ fontSize: "5rem", marginBottom: "12px" }}>
              🩺
            </div>
            <div style={{ fontWeight: 600, fontSize: "1.2rem", color: "#0f172a", letterSpacing: "-0.3px" }}>
              Your Health, Our Priority
            </div>
            <div style={{ fontSize: "0.8rem", color: "#334155", marginTop: "6px" }}>
              ⚡ 24/7 online booking
            </div>
          </div>
        </div>
      </div>

      <div style={{ background: "#fff", padding: "60px 60px" }}>
        <h2 style={{ color: "#1a1a2e", marginBottom: 32 }}>About Us</h2>
        <div className="row g-4">
          {[
            { icon: "🔍", title: "Find Doctors", text: "Search and filter doctors by specialty, location, and availability." },
            { icon: "📅", title: "Book Instantly", text: "Choose your preferred time slot and upload medical documents." },
            { icon: "🔔", title: "Get Notified", text: "Receive real-time updates on your appointment status." },
            { icon: "🛡️", title: "Secure & Private", text: "Your data is protected with JWT auth and encrypted passwords." },
          ].map((item) => (
            <div className="col-md-3" key={item.title}>
              <div className="doctor-card text-center">
                <div style={{ fontSize: "2.5rem", marginBottom: 12 }}>{item.icon}</div>
                <h5 style={{ color: "#1a1a2e" }}>{item.title}</h5>
                <p style={{ color: "#666", fontSize: "0.9rem" }}>{item.text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <footer style={{ background: "#1a1a2e", color: "#aaa", textAlign: "center", padding: "20px" }}>
        © 2026 QuickCare. All rights reserved.
      </footer>
    </>
  );
}

export default Home;
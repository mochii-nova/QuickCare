import { useEffect, useState } from "react";
import API from "../../api";

const STATUS_COLOR = {
  pending: { bg: "#fff8e1", text: "#f39c12", border: "#f39c12", icon: "⏳" },
  approved: { bg: "#e8f5e9", text: "#27ae60", border: "#27ae60", icon: "✅" },
  rejected: { bg: "#fce4ec", text: "#e74c3c", border: "#e74c3c", icon: "❌" },
};

function AdminDoctors() {
  const [doctors, setDoctors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState("");
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [toast, setToast] = useState({ msg: "", ok: true });

  const fetchDoctors = async () => {
    try {
      console.log("Fetching doctors...");
      const res = await API.get("/admin/getalldoctors");
      console.log("Doctors response:", res.data);
      if (res.data.success) setDoctors(res.data.data);
    } catch (err) {
      console.error("Error fetching doctors:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDoctors();
  }, []);

  const showToast = (msg, ok = true) => {
    setToast({ msg, ok });
    setTimeout(() => setToast({ msg: "", ok: true }), 3000);
  };

  const handleApprove = async (doctorId, userId) => {
    console.log("Approving doctor:", { doctorId, userId });
    setActionLoading(doctorId + "approve");
    try {
      const res = await API.post("/admin/getapprove", {
        doctorId,
        status: "approved",
        userid: userId,
      });
      console.log("Approve response:", res.data);
      
      if (res.data.success) {
        showToast("✅ Doctor approved successfully!");
        fetchDoctors(); 
      } else {
        showToast(res.data.message || "Approval failed", false);
      }
    } catch (error) {
      console.error("Approve error:", error);
      showToast(error.response?.data?.message || "❌ Action failed. Try again.", false);
    } finally {
      setActionLoading("");
    }
  };

  const handleReject = async (doctorId, userId) => {
    console.log("Rejecting doctor:", { doctorId, userId });
    setActionLoading(doctorId + "reject");
    try {
      const res = await API.post("/admin/getreject", {
        doctorId,
        status: "rejected",
        userid: userId,
      });
      console.log("Reject response:", res.data);
      
      if (res.data.success) {
        showToast("❌ Doctor rejected.");
        fetchDoctors(); 
      } else {
        showToast(res.data.message || "Rejection failed", false);
      }
    } catch (error) {
      console.error("Reject error:", error);
      showToast(error.response?.data?.message || "❌ Action failed. Try again.", false);
    } finally {
      setActionLoading("");
    }
  };

  const filtered = doctors.filter((d) => {
    const matchesSearch =
      d.fullName?.toLowerCase().includes(search.toLowerCase()) ||
      d.email?.toLowerCase().includes(search.toLowerCase()) ||
      d.specialization?.toLowerCase().includes(search.toLowerCase());
    const matchesStatus =
      filterStatus === "all" || d.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  if (loading) return <p style={{ color: "#888" }}>Loading doctors…</p>;

  return (
    <div>
      <h4 style={{ color: "#1a1a2e", marginBottom: 20 }}>All Doctors</h4>

      {/* Toast Notification */}
      {toast.msg && (
        <div
          className={`alert py-2 ${toast.ok ? "alert-success" : "alert-danger"}`}
          style={{ marginBottom: 16 }}
        >
          {toast.msg}
        </div>
      )}

      {/* Filters */}
      <div className="d-flex gap-3 mb-4 flex-wrap">
        <input
          className="form-control"
          style={{ maxWidth: 280 }}
          placeholder="Search by name, email, specialization…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <select
          className="form-select"
          style={{ maxWidth: 160 }}
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
        >
          <option value="all">All Statuses</option>
          <option value="pending">Pending</option>
          <option value="approved">Approved</option>
          <option value="rejected">Rejected</option>
        </select>
        <span style={{ alignSelf: "center", color: "#888", fontSize: "0.88rem" }}>
          {filtered.length} doctor{filtered.length !== 1 ? "s" : ""}
        </span>
      </div>

      {/* Doctors Table */}
      {filtered.length === 0 ? (
        <div className="alert alert-info">No doctors found.</div>
      ) : (
        <div className="table-responsive">
          <table className="table table-bordered table-hover align-middle">
            <thead style={{ background: "#f1f5f9" }}>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Specialization</th>
                <th>Experience</th>
                <th>Fee (₱)</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((doc) => {
                const colors = STATUS_COLOR[doc.status] || STATUS_COLOR.pending;
                const isBusy = actionLoading.startsWith(doc._id);
                return (
                  <tr key={doc._id}>
                    <td style={{ fontWeight: 500 }}>Dr. {doc.fullName}</td>
                    <td style={{ fontSize: "0.88rem" }}>{doc.email}</td>
                    <td style={{ fontSize: "0.88rem" }}>{doc.phone}</td>
                    <td>{doc.specialization}</td>
                    <td>{doc.experience} yrs</td>
                    <td>₱{doc.fees}</td>
                    <td>
                      <span
                        style={{
                          background: colors.bg,
                          color: colors.text,
                          border: `1px solid ${colors.border}`,
                          padding: "3px 12px",
                          borderRadius: 20,
                          fontWeight: 600,
                          fontSize: "0.8rem",
                        }}
                      >
                        {doc.status}
                      </span>
                    </td>
                    <td>
                      <div className="d-flex gap-2">
                        {doc.status !== "approved" && (
                          <button
                            className="btn btn-sm btn-success"
                            disabled={isBusy}
                            onClick={() => handleApprove(doc._id, doc.userId)}
                          >
                            {actionLoading === doc._id + "approve" ? "..." : "Approve"}
                          </button>
                        )}
                        {doc.status !== "rejected" && (
                          <button
                            className="btn btn-sm btn-danger"
                            disabled={isBusy}
                            onClick={() => handleReject(doc._id, doc.userId)}
                          >
                            {actionLoading === doc._id + "reject" ? "..." : "Reject"}
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default AdminDoctors;
import { useEffect, useState } from "react";
import API from "../../api";

function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filterRole, setFilterRole] = useState("all");

  useEffect(() => {
    const fetch = async () => {
      try {
        const res = await API.get("/admin/getallusers");
        if (res.data.success) setUsers(res.data.data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetch();
  }, []);

  const filtered = users.filter((u) => {
    const matchesSearch =
      u.fullName?.toLowerCase().includes(search.toLowerCase()) ||
      u.email?.toLowerCase().includes(search.toLowerCase()) ||
      u.phone?.includes(search);
    const matchesRole =
      filterRole === "all" ||
      (filterRole === "doctor" && u.isdoctor) ||
      (filterRole === "admin" && u.type === "admin") ||
      (filterRole === "user" && !u.isdoctor && u.type !== "admin");
    return matchesSearch && matchesRole;
  });

  if (loading) return <p style={{ color: "#888" }}>Loading users…</p>;

  return (
    <div>
      <h4 style={{ color: "#1a1a2e", marginBottom: 20 }}>All Users</h4>

      {/* Filters */}
      <div className="d-flex gap-3 mb-4 flex-wrap">
        <input
          className="form-control"
          style={{ maxWidth: 280 }}
          placeholder="Search by name, email or phone…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <select
          className="form-select"
          style={{ maxWidth: 160 }}
          value={filterRole}
          onChange={(e) => setFilterRole(e.target.value)}
        >
          <option value="all">All Roles</option>
          <option value="user">Patients</option>
          <option value="doctor">Doctors</option>
          <option value="admin">Admins</option>
        </select>
        <span
          style={{ alignSelf: "center", color: "#888", fontSize: "0.88rem" }}
        >
          {filtered.length} user{filtered.length !== 1 ? "s" : ""}
        </span>
      </div>

      {/* Summary cards */}
      <div className="row g-3 mb-4">
        {[
          {
            label: "Total Users",
            value: users.length,
            color: "#1a1a2e",
            bg: "#f1f5f9",
          },
          {
            label: "Patients",
            value: users.filter((u) => !u.isdoctor && u.type !== "admin")
              .length,
            color: "#0288d1",
            bg: "#e3f2fd",
          },
          {
            label: "Doctors",
            value: users.filter((u) => u.isdoctor).length,
            color: "#27ae60",
            bg: "#e8f5e9",
          },
          {
            label: "Admins",
            value: users.filter((u) => u.type === "admin").length,
            color: "#9c27b0",
            bg: "#f3e5f5",
          },
        ].map((card) => (
          <div className="col-6 col-md-3" key={card.label}>
            <div
              style={{
                background: card.bg,
                borderRadius: 12,
                padding: "16px 20px",
              }}
            >
              <div
                style={{
                  fontSize: "1.8rem",
                  fontWeight: 700,
                  color: card.color,
                }}
              >
                {card.value}
              </div>
              <div style={{ fontSize: "0.85rem", color: "#666" }}>
                {card.label}
              </div>
            </div>
          </div>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="alert alert-info">No users found.</div>
      ) : (
        <div className="table-responsive">
          <table className="table table-bordered table-hover align-middle">
            <thead style={{ background: "#f1f5f9" }}>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Role</th>
                <th>Doctor Status</th>
                <th>Joined</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((u) => (
                <tr key={u._id}>
                  <td style={{ fontWeight: 500 }}>{u.fullName}</td>
                  <td style={{ fontSize: "0.88rem" }}>{u.email}</td>
                  <td style={{ fontSize: "0.88rem" }}>{u.phone}</td>
                  <td>
                    <span
                      style={{
                        background:
                          u.type === "admin" ? "#f3e5f5" : "#e3f2fd",
                        color: u.type === "admin" ? "#9c27b0" : "#0288d1",
                        padding: "2px 10px",
                        borderRadius: 20,
                        fontSize: "0.8rem",
                        fontWeight: 600,
                      }}
                    >
                      {u.type}
                    </span>
                  </td>
                  <td>
                    {u.isdoctor ? (
                      <span
                        style={{
                          background: "#e8f5e9",
                          color: "#27ae60",
                          padding: "2px 10px",
                          borderRadius: 20,
                          fontSize: "0.8rem",
                          fontWeight: 600,
                        }}
                      >
                        ✓ Doctor
                      </span>
                    ) : (
                      <span style={{ color: "#ccc", fontSize: "0.82rem" }}>
                        —
                      </span>
                    )}
                  </td>
                  <td style={{ fontSize: "0.82rem", color: "#888" }}>
                    {u.createdAt
                      ? new Date(u.createdAt).toLocaleDateString()
                      : "—"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default AdminUsers;
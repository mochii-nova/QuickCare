import { useEffect, useState } from "react";
import API from "../../api";

const STATUS_COLOR = {
  pending: { bg: "#fff8e1", text: "#f39c12", border: "#f39c12" },
  approved: { bg: "#e8f5e9", text: "#27ae60", border: "#27ae60" },
  rejected: { bg: "#fce4ec", text: "#e74c3c", border: "#e74c3c" },
};

function AdminAppointments() {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");

  useEffect(() => {
    const fetch = async () => {
      try {
        const res = await API.get("/admin/getallAppointmentsAdmin");
        if (res.data.success) setAppointments(res.data.data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetch();
  }, []);

  const filtered = appointments.filter((a) => {
    const matchesSearch =
      a.userInfo?.fullName?.toLowerCase().includes(search.toLowerCase()) ||
      a.doctorInfo?.fullName?.toLowerCase().includes(search.toLowerCase());
    const matchesStatus =
      filterStatus === "all" || a.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  if (loading) return <p style={{ color: "#888" }}>Loading appointments…</p>;

  return (
    <div>
      <h4 style={{ color: "#1a1a2e", marginBottom: 20 }}>All Appointments</h4>

      {/* Filters */}
      <div className="d-flex gap-3 mb-4 flex-wrap">
        <input
          className="form-control"
          style={{ maxWidth: 260 }}
          placeholder="Search by patient or doctor name…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <select
          className="form-select"
          style={{ maxWidth: 160 }}
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
        >
          <option value="all">All Statuses</option>
          <option value="pending">Pending</option>
          <option value="approved">Approved</option>
          <option value="rejected">Rejected</option>
        </select>
        <span
          style={{
            alignSelf: "center",
            color: "#888",
            fontSize: "0.88rem",
          }}
        >
          {filtered.length} record{filtered.length !== 1 ? "s" : ""}
        </span>
      </div>

      {filtered.length === 0 ? (
        <div className="alert alert-info">No appointments found.</div>
      ) : (
        <div className="table-responsive">
          <table className="table table-striped table-bordered table-hover align-middle">
            <thead style={{ background: "#f1f5f9" }}>
              <tr>
                <th style={{ fontSize: "0.82rem", color: "#888" }}>
                  Appointment ID
                </th>
                <th>Patient</th>
                <th>Doctor</th>
                <th>Date &amp; Time</th>
                <th>Document</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((a) => {
                const colors =
                  STATUS_COLOR[a.status] || STATUS_COLOR.pending;
                return (
                  <tr key={a._id}>
                    <td
                      style={{
                        fontSize: "0.75rem",
                        color: "#aaa",
                        fontFamily: "monospace",
                      }}
                    >
                      {a._id}
                    </td>
                    <td>
                      <div style={{ fontWeight: 500 }}>
                        {a.userInfo?.fullName || "—"}
                      </div>
                      <div style={{ fontSize: "0.8rem", color: "#888" }}>
                        {a.userInfo?.phone || ""}
                      </div>
                    </td>
                    <td>
                      <div style={{ fontWeight: 500 }}>
                        Dr. {a.doctorInfo?.fullName || "—"}
                      </div>
                      <div style={{ fontSize: "0.8rem", color: "#888" }}>
                        {a.doctorInfo?.specialization || ""}
                      </div>
                    </td>
                    <td style={{ whiteSpace: "nowrap" }}>{a.date}</td>
                    <td>
                      {a.document ? (
                        <span
                          style={{
                            color: "#0288d1",
                            fontSize: "0.82rem",
                          }}
                        >
                          📎 Attached
                        </span>
                      ) : (
                        <span style={{ color: "#ccc", fontSize: "0.82rem" }}>
                          None
                        </span>
                      )}
                    </td>
                    <td>
                      <span
                        style={{
                          background: colors.bg,
                          color: colors.text,
                          border: `1px solid ${colors.border}`,
                          padding: "3px 12px",
                          borderRadius: 20,
                          fontWeight: 600,
                          fontSize: "0.8rem",
                          whiteSpace: "nowrap",
                        }}
                      >
                        {a.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default AdminAppointments;
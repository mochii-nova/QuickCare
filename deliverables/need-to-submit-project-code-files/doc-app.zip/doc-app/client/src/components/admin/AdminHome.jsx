import { useState } from "react";
import { useNavigate } from "react-router-dom";
import AdminAppointments from "./AdminAppointments";
import AdminDoctors from "./AdminDoctors";
import AdminUsers from "./AdminUser";

function AdminHome() {
  const navigate = useNavigate();
  const [active, setActive] = useState("appointments");
  const userData = JSON.parse(localStorage.getItem("userData") || "{}");

  const logout = () => {
    localStorage.clear();
    navigate("/login");
  };

  const navItems = [
    { key: "appointments", label: "📋 All Appointments", component: <AdminAppointments /> },
    { key: "doctors", label: "🩺 Doctors", component: <AdminDoctors /> },
    { key: "users", label: "👥 Users", component: <AdminUsers /> },
  ];

  return (
    <div className="dashboard-layout">
      <aside className="sidebar">
        <span className="sidebar-logo">QuickCare</span>
        <p style={{ color: "#aaa", fontSize: "0.8rem", marginBottom: 20 }}>Admin Panel</p>
        <ul className="sidebar-menu">
          {navItems.map((item) => (
            <li key={item.key}>
              <button
                className={active === item.key ? "active" : ""}
                onClick={() => setActive(item.key)}
              >
                {item.label}
              </button>
            </li>
          ))}
          <li>
            <button onClick={logout}>🚪 Logout</button>
          </li>
        </ul>
      </aside>

      <main className="main-content">
        <header className="main-header">
          <h5 style={{ margin: 0, color: "#1a1a2e" }}>Hi, {userData.fullName}</h5>
          <span style={{ color: "#888", fontSize: "0.9rem" }}>Administrator</span>
        </header>

        {/* Render the active component */}
        {navItems.find(item => item.key === active)?.component}
      </main>
    </div>
  );
}

export default AdminHome;
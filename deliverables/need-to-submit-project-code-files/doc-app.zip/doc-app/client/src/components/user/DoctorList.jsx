import { useState } from "react";
import { Modal, Button } from "react-bootstrap";
import API from "../../api";

function DoctorList({ doctor, userdata, userDoctorId, onBooked }) {
  const [show, setShow] = useState(false);
  const [dateTime, setDateTime] = useState("");
  const [documentFile, setDocumentFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  const minDate = new Date().toISOString().slice(0, 16);

  const handleBook = async (e) => {
    e.preventDefault();
    if (!dateTime) return setMessage("Please select a date and time.");
    setLoading(true);
    setMessage("");
    try {
      const formData = new FormData();
      if (documentFile) formData.append("image", documentFile);
      formData.append("date", dateTime.replace("T", " "));
      formData.append("userId", userDoctorId);
      formData.append("doctorId", doctor._id);
      formData.append("userInfo", JSON.stringify(userdata));
      formData.append("doctorInfo", JSON.stringify(doctor));

      const res = await API.post("/user/getappointment", formData);
      if (res.data.success) {
        setMessage("✅ Appointment booked! The doctor will confirm shortly.");
        if (onBooked) onBooked();
        setTimeout(() => setShow(false), 1800);
      } else {
        setMessage(res.data.message);
      }
    } catch {
      setMessage("Booking failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <div className="doctor-card">
        <div className="d-flex justify-content-between align-items-start">
          <div>
            <h5 style={{ color: "#1a1a2e", marginBottom: 4 }}>
              Dr. {doctor.fullName}
            </h5>
            <p style={{ color: "#0288d1", fontWeight: 600, marginBottom: 6 }}>
              {doctor.specialization}
            </p>
            <p style={{ color: "#555", fontSize: "0.88rem", margin: 0 }}>
              📞 {doctor.phone} &nbsp;|&nbsp; 📍 {doctor.address}
            </p>
            <p style={{ color: "#555", fontSize: "0.88rem", margin: "4px 0 0" }}>
              💼 {doctor.experience} yrs exp &nbsp;|&nbsp; 💵 ₱{doctor.fees} &nbsp;|&nbsp;
              🕐 {doctor.timings?.[0]} – {doctor.timings?.[1]}
            </p>
          </div>
          <button
            className="btn btn-info text-white"
            style={{ borderRadius: 8, whiteSpace: "nowrap" }}
            onClick={() => setShow(true)}
          >
            Book Now
          </button>
        </div>
      </div>

      <Modal show={show} onHide={() => setShow(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Book Appointment</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p style={{ fontWeight: 600, marginBottom: 4 }}>
            Dr. {doctor.fullName} — {doctor.specialization}
          </p>
          <p style={{ fontSize: "0.85rem", color: "#888", marginBottom: 16 }}>
            Fee: ₱{doctor.fees} &nbsp;|&nbsp; Hours: {doctor.timings?.[0]} – {doctor.timings?.[1]}
          </p>
          {message && (
            <div
              className={`alert py-2 ${message.startsWith("✅") ? "alert-success" : "alert-danger"}`}
            >
              {message}
            </div>
          )}
          <form onSubmit={handleBook}>
            <div className="form-group mb-3">
              <label style={{ fontWeight: 500 }}>Appointment Date & Time</label>
              <input
                type="datetime-local"
                className="form-control mt-1"
                value={dateTime}
                min={minDate}
                onChange={(e) => setDateTime(e.target.value)}
              />
            </div>
            <div className="form-group mb-3">
              <label style={{ fontWeight: 500 }}>
                Upload Document <span style={{ color: "#aaa", fontWeight: 400 }}>(optional)</span>
              </label>
              <input
                type="file"
                className="form-control mt-1"
                accept=".pdf,.jpg,.jpeg,.png"
                onChange={(e) => setDocumentFile(e.target.files[0])}
              />
            </div>
            <div className="d-flex gap-2 justify-content-end">
              <Button variant="secondary" onClick={() => setShow(false)}>
                Close
              </Button>
              <Button variant="info" className="text-white" type="submit" disabled={loading}>
                {loading ? "Booking…" : "Book"}
              </Button>
            </div>
          </form>
        </Modal.Body>
      </Modal>
    </>
  );
}

export default DoctorList;
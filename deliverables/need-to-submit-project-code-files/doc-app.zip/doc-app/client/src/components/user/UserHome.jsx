import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../../api";
import DoctorList from "./DoctorList";
import ApplyDoctor from "./ApplyDoctor";
import UserAppointments from "./UserAppointments";
import Notification from "../common/Notification";

function UserHome() {
  const navigate = useNavigate();
  const [doctors, setDoctors] = useState([]);
  const [userdata, setUserdata] = useState(null);
  const [active, setActive] = useState("home");

  useEffect(() => {
    const init = async () => {
      // Re-fetch fresh user data so isdoctor flag stays current
      try {
        const res = await API.post("/user/getuserdata", {});
        if (res.data.success) {
          const fresh = res.data.data;
          localStorage.setItem("userData", JSON.stringify(fresh));
          // If admin approved this user as a doctor, redirect them
          if (fresh.isdoctor) {
            navigate("/doctorhome");
            return;
          }
          setUserdata(fresh);
        }
      } catch {
        const stored = localStorage.getItem("userData");
        if (stored) setUserdata(JSON.parse(stored));
      }
      fetchDoctors();
    };
    init();
  }, [navigate]);

  const fetchDoctors = async () => {
    try {
      const res = await API.get("/user/getalldoctorsu");
      if (res.data.success) setDoctors(res.data.data);
    } catch (err) {
      console.error(err);
    }
  };

  const logout = () => {
    localStorage.clear();
    navigate("/login");
  };

  const unreadCount = userdata?.notification?.length || 0;

  const navItems = [
    { key: "home", label: "🏠 Home" },
    { key: "appointments", label: "📅 Appointments" },
    ...(!userdata?.isdoctor ? [{ key: "applyDoctor", label: "🩺 Apply as Doctor" }] : []),
    { key: "notifications", label: `🔔 Notifications${unreadCount > 0 ? ` (${unreadCount})` : ""}` },
  ];

  return (
    <div className="dashboard-layout">
      <aside className="sidebar">
        <span className="sidebar-logo">QuickCare</span>
        <ul className="sidebar-menu">
          {navItems.map((item) => (
            <li key={item.key}>
              <button
                className={active === item.key ? "active" : ""}
                onClick={() => setActive(item.key)}
              >
                {item.label}
              </button>
            </li>
          ))}
          <li style={{ marginTop: "auto" }}>
            <button onClick={logout}>🚪 Logout</button>
          </li>
        </ul>
      </aside>

      <main className="main-content">
        <header className="main-header">
          <h5 style={{ margin: 0, color: "#1a1a2e" }}>
            {userdata?.fullName || "User"}
          </h5>
          <span style={{ color: "#888", fontSize: "0.9rem" }}>
            {userdata?.email}
          </span>
        </header>

        {active === "home" && (
          <>
            <h5 style={{ marginBottom: 20, color: "#555" }}>Available Doctors</h5>
            {doctors.length === 0 ? (
              <div className="alert alert-info">No approved doctors available yet.</div>
            ) : (
              doctors.map((doc) => (
                <DoctorList
                  key={doc._id}
                  doctor={doc}
                  userdata={userdata}
                  userDoctorId={userdata?._id}
                  onBooked={() => {}}
                />
              ))
            )}
          </>
        )}

        {active === "appointments" && <UserAppointments />}
        {active === "applyDoctor" && <ApplyDoctor userId={userdata?._id} />}
        {active === "notifications" && <Notification />}
      </main>
    </div>
  );
}

export default UserHome;
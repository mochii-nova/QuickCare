import { useState } from "react";
import API from "../../api";

function ApplyDoctor({ userId }) {
  const [form, setForm] = useState({
    fullName: "",
    email: "",
    phone: "",
    address: "",
    specialization: "",
    experience: "",
    fees: "",
    timings: ["", ""],
  });
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleTiming = (index, value) => {
    const newTimings = [...form.timings];
    newTimings[index] = value;
    setForm({ ...form, timings: newTimings });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage("");
    setLoading(true);
    try {
      const res = await API.post("/user/registerdoc", { ...form, userId });
      if (res.data.success) {
        setMessage("✅ Application submitted! Admin will review it shortly.");
        setForm({ fullName: "", email: "", phone: "", address: "", specialization: "", experience: "", fees: "", timings: ["", ""] });
      } else {
        setMessage(res.data.message || "Submission failed.");
      }
    } catch {
      setMessage("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: 700 }}>
      <h4 style={{ color: "#1a1a2e", marginBottom: 24 }}>Apply for Doctor Account</h4>
      {message && (
        <div className={`alert ${message.startsWith("✅") ? "alert-success" : "alert-danger"}`}>
          {message}
        </div>
      )}
      <form onSubmit={handleSubmit}>
        <div className="doctor-card mb-4">
          <h6 style={{ color: "#0288d1", marginBottom: 16 }}>Personal Details</h6>
          <div className="row g-3">
            {[
              { label: "Full Name", name: "fullName", placeholder: "Dr. Juan Dela Cruz" },
              { label: "Email", name: "email", type: "email", placeholder: "doctor@email.com" },
              { label: "Phone", name: "phone", placeholder: "09123456789" },
              { label: "Address", name: "address", placeholder: "City, Province" },
            ].map((f) => (
              <div className="col-md-6" key={f.name}>
                <label className="form-label" style={{ fontWeight: 500 }}>{f.label}</label>
                <input
                  className="form-control"
                  type={f.type || "text"}
                  name={f.name}
                  value={form[f.name]}
                  onChange={handleChange}
                  required
                  placeholder={f.placeholder}
                />
              </div>
            ))}
          </div>
        </div>

        <div className="doctor-card mb-4">
          <h6 style={{ color: "#0288d1", marginBottom: 16 }}>Professional Details</h6>
          <div className="row g-3">
            <div className="col-md-6">
              <label className="form-label" style={{ fontWeight: 500 }}>Specialization</label>
              <input
                className="form-control"
                name="specialization"
                value={form.specialization}
                onChange={handleChange}
                required
                placeholder="e.g. Cardiology"
              />
            </div>
            <div className="col-md-3">
              <label className="form-label" style={{ fontWeight: 500 }}>Experience (yrs)</label>
              <input
                className="form-control"
                name="experience"
                type="number"
                min="0"
                value={form.experience}
                onChange={handleChange}
                required
              />
            </div>
            <div className="col-md-3">
              <label className="form-label" style={{ fontWeight: 500 }}>Consultation Fee (₱)</label>
              <input
                className="form-control"
                name="fees"
                type="number"
                min="0"
                value={form.fees}
                onChange={handleChange}
                required
              />
            </div>
            <div className="col-md-6">
              <label className="form-label" style={{ fontWeight: 500 }}>Available From</label>
              <input
                className="form-control"
                type="time"
                value={form.timings[0]}
                onChange={(e) => handleTiming(0, e.target.value)}
                required
              />
            </div>
            <div className="col-md-6">
              <label className="form-label" style={{ fontWeight: 500 }}>Available Until</label>
              <input
                className="form-control"
                type="time"
                value={form.timings[1]}
                onChange={(e) => handleTiming(1, e.target.value)}
                required
              />
            </div>
          </div>
        </div>

        <button className="btn btn-info text-white px-5" type="submit" disabled={loading}>
          {loading ? "Submitting…" : "Submit Application"}
        </button>
      </form>
    </div>
  );
}

export default ApplyDoctor;
import { useEffect, useState } from "react";
import API from "../../api";

function UserAppointments() {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);

  const statusColor = { pending: "#f39c12", approved: "#27ae60", rejected: "#e74c3c" };

  useEffect(() => {
    const fetch = async () => {
      try {
        const res = await API.get("/user/getuserappointments");
        if (res.data.success) setAppointments(res.data.data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetch();
  }, []);

  if (loading) return <p>Loading appointments…</p>;

  return (
    <div>
      <h4 style={{ color: "#1a1a2e", marginBottom: 20 }}>My Appointments</h4>
      {appointments.length === 0 ? (
        <div className="alert alert-info">No appointments yet.</div>
      ) : (
        <div className="table-responsive">
          <table className="table table-hover">
            <thead style={{ background: "#f1f5f9" }}>
              <tr>
                <th>Doctor</th>
                <th>Date & Time</th>
                <th>Document</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {appointments.map((appt) => (
                <tr key={appt._id}>
                  <td>Dr. {appt.docName || appt.doctorInfo?.fullName || "—"}</td>
                  <td>{appt.date}</td>
                  <td>
                    {appt.document ? (
                      <span style={{ color: "#0288d1", fontSize: "0.85rem" }}>
                        {appt.document.originalname || "Uploaded"}
                      </span>
                    ) : (
                      <span style={{ color: "#aaa" }}>None</span>
                    )}
                  </td>
                  <td>
                    <span
                      style={{
                        background: statusColor[appt.status] + "22",
                        color: statusColor[appt.status],
                        padding: "3px 10px",
                        borderRadius: 20,
                        fontWeight: 600,
                        fontSize: "0.85rem",
                      }}
                    >
                      {appt.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default UserAppointments;